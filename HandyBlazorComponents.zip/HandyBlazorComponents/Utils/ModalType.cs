
namespace HandyBlazorComponents.Utils;

public enum ModalType
{
    ERROR,
    WARNING,
    SUCCESS,
    INFO,
}
